import React from 'react';
import ReactDOM from 'react-dom';
//import './Survey.css';

class Survey extends React.Component {



  render(){

    return(
      <div className="surveypage w3-container w3-Black">
      <header>
      <center>
      <h1 className="heading">
    MAP SURVEYING TOOL

      </h1>
      </center>



      </header>
</div>
    );
  }
}

export default Survey;
