import React from 'react';
import ReactDOM from 'react-dom';

class news extends React.Component {



  render(){

    return(
      <div className="newspage">
      <h1> news!!!</h1>
      </div>
    );
  }
}

export default news;
